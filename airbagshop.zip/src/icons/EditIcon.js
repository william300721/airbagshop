import React from "react";

const EditIcon = () => {
  return (
    <svg
      width="48"
      height="48"
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_100_1445)">
        <path
          d="M28.12 18.04L29.96 19.88L11.84 38H10V36.16L28.12 18.04ZM35.32 6C34.82 6 34.3 6.2 33.92 6.58L30.26 10.24L37.76 17.74L41.42 14.08C42.2 13.3 42.2 12.04 41.42 11.26L36.74 6.58C36.34 6.18 35.84 6 35.32 6ZM28.12 12.38L6 34.5V42H13.5L35.62 19.88L28.12 12.38Z"
          fill="#2165B7"
        />
      </g>
      <defs>
        <clipPath id="clip0_100_1445">
          <rect width="48" height="48" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export default EditIcon;
