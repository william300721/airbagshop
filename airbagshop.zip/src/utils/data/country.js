export const countries = [
  {
    id: 1,
    name: "Nederlands",
    image: "/assets/images/countries/netherlands.svg",
  },
  {
    id: 2,
    name: "Français",
    image: "/assets/images/countries/france.svg",
  },
  {
    id: 3,
    name: "English",
    image: "/assets/images/countries/england.svg",
  },
  {
    id: 4,
    name: "Deutsch",
    image: "/assets/images/countries/germany.svg",
  },
  {
    id: 5,
    name: "Italiano",
    image: "/assets/images/countries/italy.svg",
  },
];
